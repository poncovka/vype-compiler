'''
test_codegen.py

Tests with code generation errors.
'''

from base import TestCase, Error

class CodeGenTestCase(TestCase):
  prefix = 'gen'

